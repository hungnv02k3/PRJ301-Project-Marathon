/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controllers;

import dal.EventDAO;
import dal.RegistrationDAO;
import dal.RunnerDAO;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.sql.Date;
import models.Account;
import models.Event;
import models.Registration;
import models.Runner;
import utils.EmailUtil;

/**
 *
 * @author User
 */
public class RegisterController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet RegisterController</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet RegisterController at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        Date today = new Date(System.currentTimeMillis());
        Account account = (Account) session.getAttribute("account");
        RunnerDAO runnerDAO = new RunnerDAO();
        EventDAO eventDAO = new EventDAO();
        if (account == null) {
            response.sendRedirect("login");
        } else {
            int eventId = Integer.parseInt(request.getParameter("eventId"));
            int runnerId = (int) session.getAttribute("runnerId");
            RegistrationDAO dao = new RegistrationDAO();

            String status = dao.getRegistrationStatus(eventId, runnerId);

            if ("Registered".equals(status) || "ACCEPTED".equals(status)) {

                session.setAttribute("msg", "You already registered this event.");

            } else if ("CANCELLED".equals(status)) {

                dao.reRegister(eventId, runnerId, today);
                session.setAttribute("msg", "Register again successfully!");

            } else {
                Runner runner = runnerDAO.getRunnerByAccountId(account.getAccountId());
                Event event = eventDAO.getEventById(eventId);

                EmailUtil.sendRegistrationMail(
                        runner.getEmail(),
                        runner.getFullName(),
                        event.getEventName(),
                        event.getEventDate().toString(),
                        event.getLocation()
                );
                // chưa từng đăng ký → INSERT
                Registration reg
                        = new Registration(eventId, runnerId, runnerId, today, "", "Registered");
                dao.insertRegistration(reg);
                session.setAttribute("msg", "Register successfully!");
            }

            response.sendRedirect("home");
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
