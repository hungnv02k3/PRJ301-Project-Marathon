/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import models.Account;

/**
 *
 * @author User
 */
public class AccountDAO extends DBContext {

    private PreparedStatement stm;
    private ResultSet rs;

    public int insertAccount(Account acc) {
        String sql = "INSERT INTO Accounts(username, password, role) VALUES(?,?,?)";

        try {
            stm = connection.prepareStatement(
                    sql,
                    PreparedStatement.RETURN_GENERATED_KEYS
            );
            stm.setString(1, acc.getUserName());
            stm.setString(2, acc.getPassword());
            stm.setString(3, acc.getRole());
            stm.executeUpdate();
            rs = stm.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1); // account_id
            }

        } catch (Exception e) {
            e.printStackTrace(); // BẮT BUỘC
        }
        return -1;
    }

    public Account getAccountByUsername(String username) {
        try {
            String sql = "SELECT account_id, username, password, role "
                    + "FROM Accounts WHERE username = ?";

            stm = connection.prepareStatement(sql);
            stm.setString(1, username);
            rs = stm.executeQuery();

            if (rs.next()) {
                Account acc = new Account();
                acc.setAccountId(rs.getInt("account_id"));
                acc.setUserName(rs.getString("username"));
                acc.setPassword(rs.getString("password"));
                acc.setRole(rs.getString("role"));
                return acc;
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }

    public List<Account> getAllAccount() {
        List<Account> list = new ArrayList<>();
        String sql = "SELECT * FROM Accounts";

        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) { // ✅ PHẢI dùng while
                Account acc = new Account(
                        rs.getInt("account_id"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("role")
                );
                list.add(acc); // ✅ add vào list
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public Account getAccountById(int id) {
        String sql = "SELECT * FROM Accounts WHERE account_id = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new Account(
                        rs.getInt("account_id"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("role")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public void updateAccount(Account acc) {
        String sql = "UPDATE Accounts SET username = ?, role = ? WHERE account_id = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, acc.getUserName());
            ps.setString(2, acc.getRole());
            ps.setInt(3, acc.getAccountId());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Account> searchByName(String keyword) {
        List<Account> list = new ArrayList<>();
        String sql = "SELECT * FROM Accounts WHERE username LIKE ?";

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, "%" + keyword + "%");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                list.add(new Account(
                        rs.getInt("account_id"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("role")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public void deleteAccount(int accountId) {
        String sql = "DELETE FROM Accounts WHERE account_id = ?";

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, accountId);
            int rows = ps.executeUpdate();

            System.out.println("Rows deleted = " + rows);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean isUsernameExist(String username) {
        String sql = "SELECT 1 FROM Accounts WHERE username = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // thêm account
    public void insert(Account acc) {
        String sql = "INSERT INTO Accounts(username, password, role) VALUES (?, ?, ?)";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, acc.getUserName());
            ps.setString(2, acc.getPassword());
            ps.setString(3, acc.getRole());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateAccountWithoutPassword(int id, String username, String role) {
        String sql = "UPDATE Accounts SET username = ?, role = ? WHERE account_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, role);
            ps.setInt(3, id);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    
    public void updateAccountWithPassword(int id, String username, String password, String role) {
    String sql = "UPDATE Accounts SET username = ?, password = ?, role = ? WHERE account_id = ?";
    try (PreparedStatement ps = connection.prepareStatement(sql)) {
        ps.setString(1, username);
        ps.setString(2, password);
        ps.setString(3, role);
        ps.setInt(4, id);
        ps.executeUpdate();
    } catch (Exception e) {
        e.printStackTrace();
    }
}
}
