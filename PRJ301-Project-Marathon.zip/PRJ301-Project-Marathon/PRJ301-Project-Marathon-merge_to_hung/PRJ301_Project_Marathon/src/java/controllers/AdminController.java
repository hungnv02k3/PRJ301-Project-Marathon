/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

package controllers;

import dal.AccountDAO;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import models.Account;

/**
 *
 * @author ADMIN
 */
public class AdminController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("Account.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String role = request.getParameter("role");

        AccountDAO dao = new AccountDAO();

        // validate
        if (username == null || username.isBlank()
                || password == null || password.isBlank()) {
            request.setAttribute("error", "Username và Password không được rỗng!");
            request.getRequestDispatcher("Account.jsp").forward(request, response);
            return;
        }

        if (dao.isUsernameExist(username)) {
            request.setAttribute("error", "Username đã tồn tại!");
            request.getRequestDispatcher("Account.jsp").forward(request, response);
            return;
        }

        Account acc = new Account(username, password, role);
        dao.insert(acc);

        request.setAttribute("msg", "Thêm account thành công!");
        request.getRequestDispatcher("Account.jsp").forward(request, response);
    }
}
