/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controllers;

import dal.AccountDAO;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.List;
import models.Account;

/**
 *
 * @author ADMIN
 */
@WebServlet(name = "AdminHomeServlet", urlPatterns = {"/admin/home"})
public class AdminHomeServlet extends HttpServlet {

    // HIỂN THỊ FORM
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("account") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        Account admin = (Account) session.getAttribute("account");
        if (!"admin".equals(admin.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String action = request.getParameter("action");
        AccountDAO dao = new AccountDAO();

        // ========== EDIT ==========
        if ("edit".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            Account acc = dao.getAccountById(id);

            request.setAttribute("acc", acc);
            request.getRequestDispatcher("/views/admin/update.jsp")
                    .forward(request, response);
        } // ========== DELETE ==========
        else if ("delete".equals(action)) {
            int id = Integer.parseInt(request.getParameter("accountId"));
            dao.deleteAccount(id);
            response.sendRedirect(request.getContextPath() + "/admin/home");
        } // ========== SEARCH ==========
        else if ("search".equals(action)) {
            String keyword = request.getParameter("keyword");

            List<Account> list = dao.searchByName(keyword);
            request.setAttribute("listAccount", list);
            request.setAttribute("keyword", keyword);

            request.getRequestDispatcher("/views/admin/home.jsp")
                    .forward(request, response);
        } // ========== LIST ==========
        else {
            List<Account> list = dao.getAllAccount();
            request.setAttribute("listAccount", list);
            request.getRequestDispatcher("/views/admin/home.jsp")
                    .forward(request, response);
        }
    }

    // XỬ LÝ UPDATE
    @Override
protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

    HttpSession session = request.getSession(false);
    if (session == null || session.getAttribute("account") == null) {
        response.sendRedirect(request.getContextPath() + "/login");
        return;
    }

    Account admin = (Account) session.getAttribute("account");
    if (!"admin".equals(admin.getRole())) {
        response.sendRedirect(request.getContextPath() + "/login");
        return;
    }

    String action = request.getParameter("action");
    AccountDAO dao = new AccountDAO();

    if ("update".equals(action)) {
        int id = Integer.parseInt(request.getParameter("id"));
        String username = request.getParameter("username");
        String password = request.getParameter("password"); // 👈 THÊM
        String role = request.getParameter("role");

        if (password == null || password.isBlank()) {
            // 🔹 KHÔNG đổi password
            dao.updateAccountWithoutPassword(id, username, role);
        } else {
            // 🔹 CÓ đổi password
            dao.updateAccountWithPassword(id, username, password, role);
        }

        response.sendRedirect(request.getContextPath() + "/admin/home");
    }
}
}
