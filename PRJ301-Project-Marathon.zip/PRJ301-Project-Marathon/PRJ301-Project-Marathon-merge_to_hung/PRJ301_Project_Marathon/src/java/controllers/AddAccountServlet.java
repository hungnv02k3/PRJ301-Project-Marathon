/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controllers;

import dal.AccountDAO;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import models.Account;

/**
 *
 * @author ADMIN
 */
@WebServlet(name = "AddAccountServlet", urlPatterns = {"/admin/add"})
public class AddAccountServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("account") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        Account admin = (Account) session.getAttribute("account");
        if (!"admin".equals(admin.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        request.getRequestDispatcher("/views/admin/add.jsp")
                .forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("account") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        Account admin = (Account) session.getAttribute("account");
        if (!"admin".equals(admin.getRole())) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String role = request.getParameter("role");

        AccountDAO dao = new AccountDAO();

        // validate
        if (username == null || username.isBlank()
                || password == null || password.isBlank()) {

            request.setAttribute("error", "Username và Password không được rỗng!");
            request.getRequestDispatcher("/views/admin/add.jsp")
                    .forward(request, response);
            return;
        }

        if (dao.isUsernameExist(username)) {
            request.setAttribute("error", "Username đã tồn tại!");
            request.getRequestDispatcher("/views/admin/add.jsp")
                    .forward(request, response);
            return;
        }

        Account acc = new Account(username, password, role);
        dao.insert(acc);

        // ✅ QUAN TRỌNG: redirect, không forward
        response.sendRedirect(request.getContextPath() + "/admin/home");
    }
}
